# PythonOOP.png-and-Flower.py
Flower.py contains a commented Python class for a Flower with attributes and methods, demonstrating OOP. PythonOOP.png shows the code and its output.
